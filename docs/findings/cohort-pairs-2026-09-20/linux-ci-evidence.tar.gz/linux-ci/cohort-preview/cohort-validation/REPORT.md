# Synthetic candidate reanalysis

Read observations; the depth screen is not confidence.

| Sample | Position / ALT | Status | Callable depth | ALT observations |
|---|---|---|---:|---:|
| specimen-a | 10 / C | observed | 10 | 4 |
| specimen-a | 20 / G | observed | 0 | 0 |
| specimen-a | 30 / T | observed | 10 | 1 |
| specimen-a | 40 / C | observed | 12 | 2 |
| specimen-b | 10 / C | observed | 9 | 1 |
| specimen-b | 20 / G | observed | 12 | 4 |
| specimen-b | 30 / T | observed | 10 | 5 |
| specimen-b | 40 / C | unmeasured | . | . |
| specimen-c | 10 / C | observed | 10 | 0 |
| specimen-c | 20 / G | observed | 3 | 0 |
| specimen-c | 30 / T | unmeasured | . | . |
| specimen-c | 40 / C | observed | 0 | 0 |

Full commands, failures, hashing/verification/import costs and source identity are in report.json.
This tiny fixture is dominated by process startup; it does not establish an economic break-even point.
