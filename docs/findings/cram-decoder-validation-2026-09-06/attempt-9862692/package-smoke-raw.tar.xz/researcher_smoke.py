import csv, hashlib, json, os, pathlib, subprocess, sys
import pysam
base=pathlib.Path('/tmp/rosalind-cram-package-smoke')
root=base/'researcher'
binary=base/'py311/bin/rosalind'
commands=[]
def run(*args, output=None):
    command=list(map(str,args)); commands.append(command)
    print('$ '+ ' '.join(command),flush=True)
    if output:
        with pathlib.Path(output).open('w') as target:
            subprocess.run(command,check=True,stdout=target,cwd=root)
    else:
        subprocess.run(command,check=True,cwd=root)
    (base/'researcher-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
common=['--reference',root/'ex1.fa','--sites',root/'candidates.vcf','--memory-budget-mb','128']
run(binary,'analyze','evidence','--alignments',root/'sample.bam',*common,'--output',root/'evidence.tsv')
run(sys.executable,'/Users/logannye/rosalind/examples/research-filter/join.py',root/'candidates.vcf',root/'evidence.tsv',output=root/'research-review.tsv')
run(binary,'verify','--manifest',root/'evidence.tsv.manifest.json')
run(binary,'reproduce','--manifest',root/'evidence.tsv.manifest.json','--inputs',root,'--binary',binary,'--json',output=root/'evidence.replay.json')
with pysam.AlignmentFile(str(root/'sample.bam'),'rb') as source:
    with pysam.AlignmentFile(str(root/'sample.cram'),'wc',header=source.header,reference_filename=str(root/'ex1.fa'),format_options=[b'version=3.0',b'multi_seq_per_slice=0']) as target:
        for record in source:target.write(record)
pysam.index(str(root/'sample.cram'))
run(binary,'analyze','evidence','--alignments',root/'sample.cram',*common,'--output',root/'cram.evidence.tsv')
assert (root/'evidence.tsv').read_bytes()==(root/'cram.evidence.tsv').read_bytes()
run(binary,'verify','--manifest',root/'cram.evidence.tsv.manifest.json')
run(binary,'reproduce','--manifest',root/'cram.evidence.tsv.manifest.json','--inputs',root,'--binary',binary,'--json',output=root/'cram.evidence.replay.json')
run(binary,'analyze','panel-qc','--reference',root/'ex1.fa','--alignments',root/'sample.bam','--regions',root/'targets.bed','--memory-budget-mb','128','--position-output',root/'positions.arrow','--output',root/'panel.tsv')
run(binary,'verify','--manifest',root/'panel.tsv.manifest.json')
with (root/'research-review.tsv').open() as source:rows=list(csv.DictReader(source,delimiter='\t'))
assert len(rows)==4 and all(row['research_screen']=='review' for row in rows)
receipt=json.loads((root/'cram.evidence.tsv.manifest.json').read_text())
print(json.dumps({'status':'passed','candidate_records':len(rows),'bam_cram_bytes_equal':True,'decoder_measurements':{key:value for key,value in receipt['measurements'].items() if key.startswith('execution.cram.') or key.startswith('execution.decoder')},'note':'Maintainer smoke on a development host; no timing benchmark or independent-user adoption claim'},indent=2))
