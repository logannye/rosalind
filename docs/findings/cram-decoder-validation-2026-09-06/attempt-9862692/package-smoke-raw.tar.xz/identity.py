import hashlib, importlib.metadata, json, pathlib, platform, subprocess, sys, rosalind
root=pathlib.Path(sys.prefix).resolve()
module=pathlib.Path(rosalind.__file__).resolve()
assert module.is_relative_to(root), (module,root)
binary=pathlib.Path(sys.prefix)/'bin/rosalind'
result={'python':sys.version,'python_executable':sys.executable,'prefix':str(root),'imported_module':str(module),'packages':{n:importlib.metadata.version(n) for n in ('rosalind-bio','pyarrow','pysam')},'native_version':subprocess.check_output([str(binary),'--version'],text=True).strip(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'platform':platform.platform()}
assert result['native_version'].split()[-1]==result['packages']['rosalind-bio']
print(json.dumps(result,indent=2))
