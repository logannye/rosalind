# Short-read evidence semantics

`analyze evidence` and `analyze panel-qc` use evidence schema **1** for full output,
**2** for physical projections, and profile
**shortread-dna-readcount-v1**. Existing `features`, `analyze coverage`, and
`variants` keep their legacy defaults. Do not mix their similarly named columns
without explicitly matching filtering rules.

## Inputs, loci, and coordinates

Input is local, coordinate-sorted indexed BAM (BAI/CSI) or CRAM (CRAI). CRAM
requires an explicit local FASTA and adjacent FAI; no network reference lookup is
needed. Analysis references may be uncompressed FASTA plus FAI, `.rref`, or
compatible `.idx`. Contig names and lengths must match the alignment dictionary.

Supply exactly one SNV VCF/VCF.gz/BCF (`--sites`) or BED (`--regions`). Variant
selection is sequential and needs no variant index. A valid declared header is
required; truncated compressed input and undeclared fields fail. VCF REF
and each distinct ALT must be a single A/C/G/T base. REF is checked against the reference;
conflicting duplicates, indels, symbolic alleles, unknown contigs, and invalid
coordinates fail. Duplicate loci combine ALT alleles and emit one row. VCF
genotypes, FILTER labels, and INFO annotations do not change read filtering.

BED uses zero-based half-open coordinates. Its normalized union defines evidence
loci, including uncovered positions. Overlap does not duplicate evidence rows.
Output `pos` is one-based; Rust `EvidenceRow.position` is zero-based. Order follows
the reference dictionary and then numerical position. Empty selections produce a
valid empty artifact. Selection is scientific; execution tiles are not selection.

Optional `--annotated-variants` restores original variant records and allele order
using verified evidence partitions. It requires persisted evidence and the depths
and alleles groups. Its INFO annotations never replace genotypes or existing
fields. Original variant bytes participate in annotation identity separately from
normalized selection. See [variant-annotation.md](variant-annotation.md).

## Observation and filtering rules

Sample scope is resolved before locus filtering. By default, one unambiguous
`@RG SM` sample is selected automatically; a header without sample names has
explicitly unknown sample identity. Multiple declared samples, or a mixture of
named and unnamed read groups, require `--sample NAME` or `--pool-samples`.
Named selection counts only the selected sample's read groups and refuses reads
whose group is missing, undeclared, or has no sample assignment. Multiple read
groups for the same sample are combined. Explicit pooling includes all records,
including unassigned records, and is recorded as pooled rather than named.

Receipts record the resolved scope as versioned `evidence.sample_scope` JSON;
scientific and cache identities include it. `--sample NAME` and automatic
selection of the same named sample have the same scientific scope. Reads from
other named samples contribute no locus counters. Skipped indexed record visits
are execution diagnostics, not unique biological read counts.

The unit is **one aligned read base**, not a fragment or UMI consensus. Overlapping
mates count separately, and orphaned/improper pairs are not automatically removed.
Only CIGAR M, =, and X contribute matched observations. D and N consume reference
coordinates without contributing depth; I and S consume read bases without a
reference observation. H/P contribute neither. There is no BAQ adjustment,
overlap correction, duplicate discovery, local realignment, or allele calling.

Unmapped records have no counted locus. At each matched locus:

1. `prefilter_depth` counts matched observations before profile filtering.
2. Exclude secondary, supplementary, QC-failed, duplicate-flagged reads in that
   order, then unavailable MAPQ255 and MAPQ below the threshold (default 20).
3. `aligned_depth` counts the remaining matched observations.
4. Exclude unavailable BQ255, BQ below the threshold (default 20), then non-ACGT
   observations. `callable_depth` and allele/strand statistics count the remainder.

Filter counters are **exclusive first-failure** counts at a locus. A read with
multiple excluded flags increments the first applicable counter. Missing quality
never passes, even at threshold 0. Supported BQ values are 0–93, reported MAPQ0–254.
Profile overrides are explicit recipe values and alter scientific identity.

The SAM sequence symbol `=` means equality to the reference and resolves to the
supplied reference base ([SAM specification, section 1.4](https://samtools.github.io/hts-specs/SAMv1.pdf)).
An ambiguous reference remains noncallable. Coverage without reference sequence
refuses a quality-qualified `=` observation with guidance to provide a reference;
it does not silently omit that observation.

Thus `prefilter_depth >= aligned_depth >= callable_depth`, and A+C+G+T equals
callable depth. `callable` here means passing the declared technical filters, not
that a genotype is reliable or clinically interpretable.

## Counts, quality, and cycles

All reducers use checked integers. Allele counts are A/C/G/T; strand counts use
alignment strand. Quality sums and histograms include only callable observations:
94 BQ bins and 255 MAPQ bins, with no bin for missing255. Histograms permit exact
downstream quantiles without retained reads. TSV histograms encode ordered
`quality:count` pairs; `.` means all bins zero.

`read_position_sum` uses the zero-based offset in stored SEQ: reverse-strand reads
map the aligned query position back through `read_length - 1 - query_position`.
Stored sequence length includes soft clipping and excludes hard-clipped bases.
It does not reconstruct cycles removed before alignment. Derive a mean by dividing a sum by
callable depth; zero depth has no defined quality/cycle mean.

## Panel QC

The BED union is extracted once, but each original nonempty target receives its
own summary in input order. Overlapping targets each receive the overlapping
loci; equal target identifiers do not merge targets. BED column4 names a target;
otherwise a line-based identifier is supplied.

Mean callable depth divides by the **complete target length**. Uncovered bases
remain in the denominator and minimum depth. Breadth counts positions reaching
1x/10x/20x/30x callable depth. `--min-callable-depth` (default 10) supplies a separate
callable-position threshold. Without a reference, BAM dictionary coordinates are
used and reference bases are N; no reference-dependent statistic is inferred.
`--position-output` writes Arrow evidence from the same pass as the target summary.
The Rust, CLI, and Python panel interfaces share the 10x default; Python delegates
the default to its matching native executable and passes only explicit overrides.

## Execution and memory

Evidence extraction never downsamples to satisfy a budget. The engine scans
indexed intervals into bounded aggregate tiles, rather than retaining every active
read. Budget changes may reduce microtile width and repeat indexed reads. A single
record/read beyond the declared envelope or integer overflow fails the run.
Successful scientific output is invariant to budget, microtile, and worker count.

Canonical ownership tiles span 16,384 reference bases. Arrow encoding uses fixed
**1,024-row** batches independently of computation width. This differs from the
legacy feature encoder's 65,536-row batches. Full evidence retains schema-1 bytes.
Physical projections use schema 2 and a versioned field mask, stored in one
canonical Arrow metadata value. Groups are `depths` (including exclusive filter
counts), `alleles`, `strands`, `quality-sums`, `quality-histograms`, and
`read-position`, plus opt-in `allele-quality`. The latter stores four A/C/G/T
quality/position sum vectors and uses field-mask version 2. Historical `all` stays
at mask 63; `all-supported` selects all seven groups (127). Identity columns are always present; `--fields none` emits only
those columns. Omitted groups allocate no corresponding summary or encoder vectors
and never appear as zero-valued output columns. Group selection does not change
filtering, reference/CIGAR validation, or the values of retained metrics.

Panel summaries default to `depths,quality-sums`; optional position output defaults
to full evidence. An explicit panel projection must include both required groups.
The planner accounts for the chosen groups and bounded IPC frames, arrays,
serialization, reference span, and decoder overhead. Nearby disjoint selections
share fetch windows up to the admitted microtile width within each ownership tile.
Unrequested gaps are never emitted. Repeated record visits are execution diagnostics.

Dataset caches record and validate physical schema and field masks before decoding
records. Dataset comparison accepts matching masks and explicitly refuses differing
masks. Full schema-1 artifacts and their byte verification remain supported.

Plans include engine, consumer/encoder, and process overhead. The htslib record
envelope is checked after decode, so it is a cooperative check rather than an
allocation cap inside htslib. A declared budget and sampled RSS cannot prove a
universal hard OS bound. An existing Linux cgroup-v2 limit is an additional,
separately recorded assurance. Python memory retained by a consumer is outside the
native child-process budget.

Legacy pileup instead retains active observations within declared read/depth
capacities. New runs record `pileup.semantics=exact-or-fail-v1` and fail at capacity
instead of silently choosing a subset. Old receipts still verify at their original
schema capability; replay of old behavior requires the matching producer.

### CRAM decoder admission

The `cram-container-envelope-v1` execution profile supports CRAM **3.0**,
single-reference containers/slices, RAW or GZIP metadata, and RAW/GZIP/rANS4
(order 0/1) data blocks. Multi-reference layouts, other format versions/codecs,
and unsupported encoding metadata produce an explicit unsupported-request error.
Use BAM when a CRAM layout is outside this preview profile. The local decoder
FASTA must have an adjacent FAI and a matching dictionary; CRAI is required.

Before opening a native decoder, a bounded pass checks container/block metadata,
CRC and declared expansion sizes, supported encoding structures, reference spans,
and index syntax/storage. Every CRAI entry must match the scanned slice inventory;
missing, extra, or stale entries fail before indexed extraction. Explicit limits include
8 MiB metadata, 64 MiB per block,
256 MiB per container, one million records and 4,096 blocks per container. These
are admission limits, not scientific filters. Refusing an unsupported envelope
does not mean that a file is invalid in the broader CRAM specification.

Next, a **complete sequential validation pass** checks every decoded record against
the unchanged caller-supplied payload/read-length limits, including off-target
records. It checks the process budget after native reads. Native code may allocate
before that check; a detected breach is a runtime resource failure, not proof of
prospective allocation control. The final indexed-decoder plan uses the verified
whole-file maximum payload plus container, codec, reference, index and allocation
coexistence reserves. The validation peak is included in the process baseline.
Workers share the completed validation and input guards rather than each decoding
the whole file again. Inputs must remain immutable throughout. `--plan` also runs
the validation pass; a separate later CLI run validates again. Retain an open
native session when an application needs to plan and execute without repeating setup.

Plan output and receipts record `execution.decoder_model`, `execution.decoder_bytes`
and `execution.cram.*` metadata and validation measurements. Validation records,
elapsed time and maxima are execution diagnostics; they never enter per-locus
biological counts or scientific identity. The whole-file pass adds setup cost even
for sparse selections and cache resume. Zero indexed `execution.record_visits`
does **not** mean zero CRAM validation decoding. Saved-dataset queries avoid opening
the original CRAM altogether. Historical artifacts still verify; replay with
earlier execution behavior requires their matching producer.

## Identity, replay, and reuse

Scientific identity includes content, normalized selection, profile, fields, and
schema. Execution settings and outcomes are recorded separately. Input files are
hashed once per distinct path identity in a run; later runs rehash before cache
reuse. Verified atomic partitions may be reused with `--cache-dir --resume`.
Workers extract first-party partitions; custom reducers consume serially in
canonical order.

All alignment, reference, selection, and index files must remain immutable for
the entire run. Initial content hashes establish identity; before/after metadata
and inode guards detect ordinary in-place edits or file replacement during
execution. These metadata checks are not cryptographic re-verification and do not
defend against an intentional modification that restores the observed metadata.
Workers aborted by an input-change guard must not publish changed-source cache
partitions. Keep mutable upstream jobs and evidence extraction in separate stages.

Materialized outputs and their receipts support byte verification and replay.
A stdout stream has no persisted output artifact unless the consumer explicitly
stores one. Receipts are tamper-evident records, not signatures or proof of
biological accuracy. See [receipts and trust](receipts-and-trust.md).
